<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>  
<meta  charset="UTF-8">  
<title>大乐透验证码随机控内联框架版</title>  
</head>      
                
  <body>       
                                           

<h1  style="font-size:35px;color:#FF0000">

 ||  thinkphp验证码随机控内联框架版

‖‖{ 3个最重要的文件，注意事项！}
 
 ||  ||  控制器文件Lib/Actiion/IndexAction.

 class

 ||  || 前台文件  tpl/Index/index.html


‖‖{第 3个最重要的文件,注意Sting.class.php,共有3个Sting.

class.php文件容易混乱 }

‖‖注意是它→_→┏ (^ω^)=☞Think/Extend/Library/QRG/Util/Sting.class.

php‖


‖‖字符串类文件_最重要_验证码是_通过字符串类来生成的


‖不是Lib下面/ORG下面/Util/sting.class.php_不是

‖‖不是Think/Lib/ORG/Util/sting.class.php.不是

‖‖注意是它→_→┏ (^ω^)=☞Think/Extend/Library/ORG/UtiI/sting.class.


‖‖文件_最重要_验证码是_通过字符串类来生成的

  
</><hr><br>


<h1 style="font-size:35px;color:#FF0000">TinkPHP_dlt3_内联框架_打乱控位_验证码前区            
  </><img  src="__URL__/index" width=900 height=200>   <br>  <hr>                             
 <h1 style="font-size:35px;color:#FF0000">TinkPHP_dlt3_内联框架_打乱控位_验证码后区</><img    src="__URL__/verify" width=900 height=200>

</body>         
                         
 </html>