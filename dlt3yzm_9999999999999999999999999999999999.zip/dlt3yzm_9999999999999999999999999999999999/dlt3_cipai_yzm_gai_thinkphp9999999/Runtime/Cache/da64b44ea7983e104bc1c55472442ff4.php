<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>  
<meta  charset="UTF-8">  
<title>大乐透TP验证码版随机控位版2016新版</title>  
</head>      
                
  <body>       
                                           
  <h1  style="font-size:35px;color:#FF0000">‖A=10.‖ B=11.‖C=12.‖ D=13.‖ E=14 .‖F=15 .‖G=16.‖ H=17.‖ I=18. ‖J=19. ‖K=20. ‖L=21.‖ M=22 .‖ N=23. ‖O=24.‖P=25.‖Q=26.‖R=27.‖S=28.‖T=29.‖U=30. ‖V=31.‖W=32.‖X=33.‖Y=34.‖Z=35.‖
  
</><hr><br>


<h1  style="font-size:35px;color:#FF0000">


‖‖{ 3个最重要的文件，注意事项！}


‖‖{ 3个最重要的文件,注意Sting.class.php,共有3个Sting.

class.php文件容易混乱 }

‖‖注意是它→_→┏ (^ω^)=☞Think/Extend/Library/QRG/Util/Sting.class.

php‖


‖‖字符串类文件_最重要_验证码是_通过字符串类来生成的


‖不是Lib下面/ORG下面/Util/sting.class.php_不是

‖‖不是Think/Lib/ORG/Util/sting.class.php.不是

‖‖注意是它→_→┏ (^ω^)=☞Think/Extend/Library/ORG/UtiI/sting.class.

‖┏ (^ω^)=☞Extend下面/Library下面/ORG/Util/Sting.class.php‖



‖‖文件_最重要_验证码是_通过字符串类来生成的

  
</><hr><br>


<h1 style="font-size:35px;color:#FF0000">大乐透_dlt+3_次排_打乱控位_验证码版前区            
  </h1><img  src="__URL__/index" width=900 height=500>   <br>  <hr>                             
 <h1 style="font-size:35px;color:#FF0000">大乐透_dlt+3_次排_打乱控位_验证码后区</h1><img    src="__URL__/verify" width=900 height=500>

</body>         
                         
   </html>